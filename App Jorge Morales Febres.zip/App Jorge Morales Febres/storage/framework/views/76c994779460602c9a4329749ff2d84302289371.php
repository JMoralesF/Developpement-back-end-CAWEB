<?php $__env->startSection('title', 'Detail of Task'); ?>

<?php $__env->startSection('main'); ?>
	<div class="task-list">
		<div class="card">
		<div class="card-header">
			<h3><?php echo e($task->title); ?></h3>
		</div>
			<div class="card-content">
				<div class="content">
					
					<p><?php echo e($task->description); ?></p>
					<br>
					
				</div>
			</div>
			<div class="card-footer">
				<p><?=date("M d Y",strtotime($task->created_at))?></p>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\todo\laravel-test-version\resources\views/view.blade.php ENDPATH**/ ?>