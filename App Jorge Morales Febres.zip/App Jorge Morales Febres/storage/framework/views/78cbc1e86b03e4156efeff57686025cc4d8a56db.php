<?php $__env->startSection('title', 'List of Tasks'); ?>

<?php $__env->startSection('main'); ?>
<div class="flash-message">
    <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if(Session::has('alert-' . $msg)): ?>

      <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
      <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div> <!-- end .flash-message -->
	<div class="task-list">
		<?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="card">
			<div class="card-content">
				<div class="content">
					<h3><?php echo e($task->title); ?></h3>
				</div>
			</div>
			<div class="card-footer">
			<div class="col-lg-3">
				<a href="/task/<?php echo e($task->id); ?>" class="">Show task ></a>
				</div>
				<div class="col-lg-6"></div>
				<div class="col-lg-3">
				<div class="" style="float: right;">
				<a  href="/task/delete/<?php echo e($task->id); ?>" class="btn btn-danger"><i class="fa fa-trash"></i> Delete</a>
				</div>
				</div>
			</div>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\todo\laravel-test-version\resources\views/index.blade.php ENDPATH**/ ?>